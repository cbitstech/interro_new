(function () {
  'use strict';

  function HomeController() {

  }

  angular.module('sis.controllers')
    .controller('HomeController',
    [ HomeController]);
})();
