(function() {
  'use strict';

  function DecisionSupportController() {

  }

  angular.module('sis.controllers')
    .controller('DecisionSupportController',
    [DecisionSupportController]);
})();
